package com.programem.seguradora;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class SeguradoraController {

    @GetMapping("/")
    public String root(){
      return "mapa";
    }


}
