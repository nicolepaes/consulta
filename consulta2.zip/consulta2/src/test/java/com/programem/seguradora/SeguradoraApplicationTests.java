package com.programem.seguradora;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SeguradoraApplicationTests {

	@Test
	void contextLoads() {
	}

}
